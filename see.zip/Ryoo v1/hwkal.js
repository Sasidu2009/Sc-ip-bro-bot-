// Buat Lu Yang Jual Sc Ini Gw Tonjok 



const fs = require('fs')
const chalk = require('chalk')

global.gr = 'https://wa.me/94712235129?text=bang+aku+mau+donasi+i+love+yuuu'
global.ig = 'https://instagram/@oktaofcrill' // ubah aja
global.taa = 'https://taaofc-panel.my.id'
global.gh = 'https://github.com/chataofc'
global.email = 'zyyyzeus@gmail.com' //serah
global.region = 'indonesia' // serah
global.dana = '94712235129'
global.gopay = '94712235129'
global.pulsa = '94712235129'
//—————「 Set Nama Own & Bot 」—————//
global.ownername = '𝗢𝚔𝚝𝚊' //ubah jadi nama mu, note tanda ' gausah di hapus!
//=================================================//
global.owner = ['94712235129'] // ubah aja pake nomor lu
//==========================BY Hw Mods=======================//
global.keyopenai = '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'
//====================BY Hw Mods=============================//
global.botname = '𝘙𝘺𝘰 𝘠𝘢𝘮𝘢𝘥𝘢' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = '𝘙𝘺𝘰' // ubah aja ini nama sticker
global.author = '𝘽𝙮 𝙊𝙠𝙩𝙖' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'haikal' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.anticall = true
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})